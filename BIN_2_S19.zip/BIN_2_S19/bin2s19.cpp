/********************************************************************
 *
 *  File name: configux.cpp
 *
 *  Summary:   This program converts a BIN EPROM file to S19 format
 *
 *             This program was modified using "SerialTest" (written by DianaS.)
 *             as the basis.  All changes written by Joe Haas, KE0FF on or after
 *             19-JAN-2021.
 *
 *  Called via:   WIN command prompt.  See help listings for ARGS
 *
 *   Currently, inout and output filenames are fixed, as is the file size (8192 bytes)
 *      little-to-no error checking is done.
 * 
 *   Produces "srec.txt" from file named "inbin.bin" located in the same folder as this
 *      executable.  The srec.txt file includes a data CRC16 at the end of the file.
 *
 *
 *******************************************************************/
/*
// ******************************************************************
//
// Revision History:
//------------------------------------------------------------------------------------------------------------------
//    04-30-24 jmh:  Basic features complete.  Need error checking and more UI features
//                   Parsed from configux program.
//    01-19-21 jmh:  copied project from SerialTest with many thanks to DianaS.
//    V0.0
// ******************************************************************
*/
#include "stdafx.h"

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <time.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <sys/timeb.h>

#include "scrndisp.h"
#include "scrnattr.h"


#define VERSION     "0.0"

#define CR          0x0d                 /* ASCII carriage return */
#define ESC         0x1b                 /* ASCII ESCape character */
#define BEL         0x07                 /* ASCII BEL character */
#define DEF_COM     4                    /* default COM port */

unsigned char lastScrollRowUsed;
unsigned char scrollRow;
unsigned char scrollCol;

char get_hex(char* s);
char upcase(char c);
void zero_pad(char* nstr, size_t s);
bool is_num(char c);
bool is_hex(char c);
bool is_hex_word(char* hstr);
char press_any_key(bool escmsg);
char get_key(void);
void bputs(const char* hstr, const char* fname, char flag);

void print_cli_help(void);
static void help_screen(bool filewrite);
unsigned int calcrc(char c, unsigned int oldcrc, unsigned int poly);
void dobins19(void);

/********************************************************************
 *
 * Function: main
 *
 * Requirements Summary:  Initialize the PC serial port as required
 *      by the program's input parameters and print received bytes
 *      on the screen in hex format.
 *
 * Return value: normal DOS exit
 *
 * Limitations:
 *   none.
 *
 * Notes:
 * Communitcates with operator and target radio to compute and exchange
 *   config data.  Detects radio reset and auto-copies current config
 *   (need a switch to disable that feature).  Updates radio in real-time
 *   and provides rssi and COS/PTT status.  User initiates FLASH Write
 *   and ErAse commands.
 *
 * Revision History:
 *    01-20-21 jmh:  creation date - copied from SerialTest, modified for UXFF
 *
 *******************************************************************/
int _tmain(int argc, _TCHAR* argv[])
{
    char* fp;                       /* file temps */
    FILE* filename;
    errno_t err;
    char  input_str[20];
    char obuf[80];                  /* serial tx buffer */

    init_screen(WINDOW_WIDTH_IN_CHARS, WINDOW_LENGTH_IN_LINES);
    fflush(stdin);

    set_text_color(LABEL_COLOR, BACK_COLOR);
    _cprintf("BIN-2-S19 Converter Version %s %c2024 by Joseph M. Haas, KE0FF\n\n", VERSION, CPYRT);

    dobins19();
    return 0;
}
#undef TX_RATE_MS
#undef MS_PER_SEC
// end main //


///////////////////////////////////
//  display windows command line help
///////////////////////////////////
void print_cli_help(void) {
    printf("Usage:  bin2s19 <args>\n\n");
    printf("Valid <args>:\n");
    printf("  <?> Usage help\n");
    return;
}

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// get_hex() returns hex conversion of two ASCII chars at *s
//-----------------------------------------------------------------------------
char get_hex(char* s) {
    char    i;     // temps
    char    j;
    char* lptr = s;

    i = upcase(*lptr++);
    if ((i < '0') || (i > 'F')) i = '0';    // force to 0 if invalid
    i -= '0';                               // convert to number
    if (i > 9) i -= 'A' - '9' - 1;
    j = upcase(*lptr);
    if ((j < '0') || (j > 'F')) j = '0';    // force to 0 if invalid
    j -= '0';                               // convert to number
    if (j > 9) j -= 'A' - '9' - 1;
    return ((i << 4) | j);
}

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// upcase() returns upper case value of ASCII character
//-----------------------------------------------------------------------------
char upcase(char c) {
    char    i = c;     // temp

    if ((c >= 'a') && (c <= 'z')) i = c - ('a' - 'A');        // upcase
    return (i);
}

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// is_num() returns true if character is an ASCII decimal digit
//-----------------------------------------------------------------------------
bool is_num(char c) {
    bool    i = false;     // return temp

    if ((c >= '0') && (c <= '9')) i = true;
    return (i);
}

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// zero_pad() replaces all space characters in nstr with '0'
//-----------------------------------------------------------------------------
void zero_pad(char* nstr, size_t s) {
    size_t  i = s;

    while ((*nstr) && (i)) {
        if (*nstr == ' ') *nstr = '0';
        nstr++;
        i--;
    }
    return;
}

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// is_hex() returns true if character is an ASCII hexidecimal digit
//-----------------------------------------------------------------------------
bool is_hex(char c) {
    bool    i = false;     // return temp

    if ((c >= '0') && (c <= '9')) i = true;
    if ((c >= 'A') && (c <= 'F')) i = true;
    if ((c >= 'a') && (c <= 'f')) i = true;
    return (i);
}

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// is_hex_word() returns true if 8 characters at char pointer are ASCII hex digits
//-----------------------------------------------------------------------------
bool is_hex_word(char* hstr) {
    char*   hptr = hstr;
    char    i;
    bool    good = true;

    for (i = 0; i < 8; i++) {
        if (!is_hex(*hptr++)) good = false;
    }
    return good;
}


///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// press_any_key() waits for user keypress.
//  escmsg determines display message
//-----------------------------------------------------------------------------
char press_any_key(bool escmsg) {
    char c;

    set_text_color(DATA_COLOR, BACK_COLOR);
    if (escmsg) {
        _cputs("Press any key to continue, ESC to exit...");
    }else{
        _cputs("Press any key to continue...");
    }
    c = get_key();
    return c;
}

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// get_key() waits for user keypress and returns chr
//-----------------------------------------------------------------------------
char get_key(void) {

    while (_kbhit() == 0);          // loop here until keypress
    return _getch();
    }

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// bputs() dual-directs string output to console and a file
//-----------------------------------------------------------------------------
void bputs(char* hstr, const char* fname, char flag) {
    //#define LINE_MAX    80
    //    char    in_str[LINE_MAX];

    static FILE* filename;
    static errno_t err;

    _cputs(hstr);
    switch (flag) {
    case 0x7f:
        // init file out
        err = fopen_s(&filename, "srec.txt", "w");
        if (!err) {
            flag = 1;
        }
        else {
            gopos(BOTTOM_ROW + 1, 1);
            clr_to_eol();
            printf_s("File error: %u", err);
        }
        break;

    case 1:
        // fputs()
        if (filename != NULL) {
            fputs(hstr, filename);
        }
        break;

    case 2:
        if (filename != NULL) {
            fclose(filename);
            if (!err) {
                printf_s("File saved.");
            }
            else {
                printf_s("Save error.");
            }
        }
        break;
    }
    return;
}

//-----------------------------------------------------------------------------
// calcrc() calculates incremental crcsum using supplied poly
//	(xmodem poly = 0x1021)
//-----------------------------------------------------------------------------
#define	XPOLY	0x1021				// polynomial seed for CRC
unsigned int calcrc(char c, unsigned int oldcrc, unsigned int poly) {

    unsigned int crc;
    char	i;

    crc = oldcrc ^ ((unsigned int)c << 8);
    for (i = 0; i < 8; ++i) {
        if (crc & 0x8000) crc = (crc << 1) ^ poly;
        else crc = crc << 1;
    }
    return crc;
}

///////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------
// dobins19() does a file conversion binary to S19
//-----------------------------------------------------------------------------

void dobins19(void) {
    char            sbuf[128];
    size_t          size;                 // temps
    size_t          byte;                 // temps
    unsigned int    i, j, k, addr, chks, crc;
    size_t          qbuf[8192];
    errno_t         err;
    FILE* binary;
    //   FILE* stream;
#define FILEMAX 8192

//    bputs("bin>>srec", "out.txt", 0x7f);               // open output file
//    err = _set_fmode(_O_BINARY);
    err = fopen_s(&binary, "inbin.bin", "rb");  // Open binary file
    size = fread(qbuf, 1, 8192, binary);
    fclose(binary);
    printf("size = %d\n", (unsigned int)size);
    sbuf[0] = '\0';
    bputs(sbuf, "out.s19", 0x7f);
    addr = 0;
    j = 0;
    crc = 0;
    while(addr < FILEMAX) {
        sprintf_s(sbuf,"S113%04X", addr);
        bputs(sbuf, "out.s19", 1);
        chks = 0x13 + ((addr >> 8) & 0xff) + (addr & 0xff);
        byte = qbuf[j];
        for (i = 0; i < 8; i++) {
            k = (unsigned int)(byte & 0xff);
            chks += k;
            sprintf_s(sbuf,"%02X", k);
            bputs(sbuf, "out.s19", 1);
            crc = calcrc((char)k, crc, XPOLY);

            byte >>= 8;
        }
        byte = qbuf[j+1];
        for (i = 0; i < 8; i++) {
            k = (unsigned int)(byte & 0xff);
            chks += k;
            sprintf_s(sbuf,"%02X", k);
            bputs(sbuf, "out.s19", 1);
            crc = calcrc((char)k, crc, XPOLY);
            byte >>= 8;
        }
        chks = ~chks & 0xff;
        sprintf_s(sbuf,"%02X\n", chks);
        bputs(sbuf, "out.s19", 1);
        addr += 16;
        j += 2;
    }
    sprintf_s(sbuf, "S9030000FC\n\n");
    bputs(sbuf, "out.s19", 1);
    sprintf_s(sbuf, "CRC16: $%04X (data)\n", crc & 0xffff);
    bputs(sbuf, "out.s19", 1);
    sbuf[0] = '\0';
    bputs(sbuf, "out.s19", 2);
    return;
}

//////////////////////////
// END SOURCE... main() //
//////////////////////////
